import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import CodeBlock from "./code-block"
import { modelCode, controllerCode, serviceCode, securityCode, configCode } from "./code-samples"

export default function SourcePage() {
  return (
    <div className="container mx-auto py-10">
      <h1 className="text-3xl font-bold mb-6">Código-fonte da API Najason</h1>

      <Tabs defaultValue="models">
        <TabsList className="grid w-full grid-cols-5">
          <TabsTrigger value="models">Modelos</TabsTrigger>
          <TabsTrigger value="controllers">Controllers</TabsTrigger>
          <TabsTrigger value="services">Serviços</TabsTrigger>
          <TabsTrigger value="security">Segurança</TabsTrigger>
          <TabsTrigger value="config">Configuração</TabsTrigger>
        </TabsList>

        <TabsContent value="models">
          <Card>
            <CardHeader>
              <CardTitle>Modelos de Dados</CardTitle>
              <CardDescription>Entidades que representam os dados dos fornecedores</CardDescription>
            </CardHeader>
            <CardContent>
              <CodeBlock code={modelCode} language="java" />
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="controllers">
          <Card>
            <CardHeader>
              <CardTitle>Controllers REST</CardTitle>
              <CardDescription>Endpoints da API para interagir com os dados</CardDescription>
            </CardHeader>
            <CardContent>
              <CodeBlock code={controllerCode} language="java" />
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="services">
          <Card>
            <CardHeader>
              <CardTitle>Serviços</CardTitle>
              <CardDescription>Lógica de negócio para manipulação dos dados</CardDescription>
            </CardHeader>
            <CardContent>
              <CodeBlock code={serviceCode} language="java" />
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="security">
          <Card>
            <CardHeader>
              <CardTitle>Configuração de Segurança</CardTitle>
              <CardDescription>Implementação de autenticação e autorização</CardDescription>
            </CardHeader>
            <CardContent>
              <CodeBlock code={securityCode} language="java" />
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="config">
          <Card>
            <CardHeader>
              <CardTitle>Configuração da API</CardTitle>
              <CardDescription>Configurações do Spring Boot e OpenAPI</CardDescription>
            </CardHeader>
            <CardContent>
              <CodeBlock code={configCode} language="java" />
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>
    </div>
  )
}
