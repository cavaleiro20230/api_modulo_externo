"use client"

import { useEffect } from "react"
import SwaggerUI from "swagger-ui-react"
import "swagger-ui-react/swagger-ui.css"

export default function ApiDocsPage() {
  useEffect(() => {
    document.title = "Najason API - Documentação"
  }, [])

  const spec = {
    openapi: "3.0.1",
    info: {
      title: "Najason API",
      description: "API Java para o Sistema Najason de Fornecedores Externos",
      version: "1.0.0",
      contact: {
        name: "Equipe de Desenvolvimento",
        email: "dev@najason.com",
        url: "https://najason.com",
      },
      license: {
        name: "Apache 2.0",
        url: "http://www.apache.org/licenses/LICENSE-2.0.html",
      },
    },
    servers: [
      {
        url: "http://localhost:8080/najason",
        description: "Servidor de Desenvolvimento",
      },
    ],
    tags: [
      {
        name: "Supplier Management",
        description: "API para gerenciamento de fornecedores",
      },
      {
        name: "Product Management",
        description: "API para gerenciamento de produtos dos fornecedores",
      },
      {
        name: "Contract Management",
        description: "API para gerenciamento de contratos",
      },
      {
        name: "Authentication",
        description: "API para autenticação de usuários",
      },
    ],
    paths: {
      "/api/v1/suppliers": {
        get: {
          tags: ["Supplier Management"],
          summary: "Listar todos os fornecedores",
          description: "Retorna uma lista paginada de todos os fornecedores",
          operationId: "getAllSuppliers",
          parameters: [
            {
              name: "page",
              in: "query",
              description: "Número da página (0..N)",
              schema: {
                type: "integer",
                default: 0,
              },
            },
            {
              name: "size",
              in: "query",
              description: "Tamanho da página",
              schema: {
                type: "integer",
                default: 20,
              },
            },
            {
              name: "sort",
              in: "query",
              description: "Critério de ordenação: propriedade(,asc|desc)",
              schema: {
                type: "string",
              },
            },
          ],
          responses: {
            "200": {
              description: "Operação bem-sucedida",
              content: {
                "application/json": {
                  schema: {
                    $ref: "#/components/schemas/PageSupplier",
                  },
                },
              },
            },
            "401": {
              description: "Não autorizado",
            },
            "403": {
              description: "Acesso proibido",
            },
          },
          security: [
            {
              bearerAuth: [],
            },
          ],
        },
        post: {
          tags: ["Supplier Management"],
          summary: "Criar novo fornecedor",
          description: "Cria um novo fornecedor no sistema",
          operationId: "createSupplier",
          requestBody: {
            content: {
              "application/json": {
                schema: {
                  $ref: "#/components/schemas/Supplier",
                },
              },
            },
            required: true,
          },
          responses: {
            "201": {
              description: "Fornecedor criado com sucesso",
              content: {
                "application/json": {
                  schema: {
                    $ref: "#/components/schemas/Supplier",
                  },
                },
              },
            },
            "400": {
              description: "Dados inválidos",
            },
            "401": {
              description: "Não autorizado",
            },
            "403": {
              description: "Acesso proibido",
            },
          },
          security: [
            {
              bearerAuth: [],
            },
          ],
        },
      },
      "/api/v1/suppliers/{id}": {
        get: {
          tags: ["Supplier Management"],
          summary: "Obter fornecedor por ID",
          description: "Retorna um fornecedor específico pelo seu ID",
          operationId: "getSupplierById",
          parameters: [
            {
              name: "id",
              in: "path",
              description: "ID do fornecedor",
              required: true,
              schema: {
                type: "integer",
                format: "int64",
              },
            },
          ],
          responses: {
            "200": {
              description: "Operação bem-sucedida",
              content: {
                "application/json": {
                  schema: {
                    $ref: "#/components/schemas/Supplier",
                  },
                },
              },
            },
            "404": {
              description: "Fornecedor não encontrado",
            },
            "401": {
              description: "Não autorizado",
            },
            "403": {
              description: "Acesso proibido",
            },
          },
          security: [
            {
              bearerAuth: [],
            },
          ],
        },
        put: {
          tags: ["Supplier Management"],
          summary: "Atualizar fornecedor",
          description: "Atualiza os dados de um fornecedor existente",
          operationId: "updateSupplier",
          parameters: [
            {
              name: "id",
              in: "path",
              description: "ID do fornecedor",
              required: true,
              schema: {
                type: "integer",
                format: "int64",
              },
            },
          ],
          requestBody: {
            content: {
              "application/json": {
                schema: {
                  $ref: "#/components/schemas/Supplier",
                },
              },
            },
            required: true,
          },
          responses: {
            "200": {
              description: "Fornecedor atualizado com sucesso",
              content: {
                "application/json": {
                  schema: {
                    $ref: "#/components/schemas/Supplier",
                  },
                },
              },
            },
            "400": {
              description: "Dados inválidos",
            },
            "404": {
              description: "Fornecedor não encontrado",
            },
            "401": {
              description: "Não autorizado",
            },
            "403": {
              description: "Acesso proibido",
            },
          },
          security: [
            {
              bearerAuth: [],
            },
          ],
        },
        delete: {
          tags: ["Supplier Management"],
          summary: "Excluir fornecedor",
          description: "Remove um fornecedor do sistema",
          operationId: "deleteSupplier",
          parameters: [
            {
              name: "id",
              in: "path",
              description: "ID do fornecedor",
              required: true,
              schema: {
                type: "integer",
                format: "int64",
              },
            },
          ],
          responses: {
            "204": {
              description: "Fornecedor excluído com sucesso",
            },
            "404": {
              description: "Fornecedor não encontrado",
            },
            "401": {
              description: "Não autorizado",
            },
            "403": {
              description: "Acesso proibido",
            },
          },
          security: [
            {
              bearerAuth: [],
            },
          ],
        },
      },
      "/api/auth/login": {
        post: {
          tags: ["Authentication"],
          summary: "Autenticar usuário",
          description: "Autentica um usuário e retorna um token JWT",
          operationId: "authenticateUser",
          requestBody: {
            content: {
              "application/json": {
                schema: {
                  $ref: "#/components/schemas/LoginRequest",
                },
              },
            },
            required: true,
          },
          responses: {
            "200": {
              description: "Autenticação bem-sucedida",
              content: {
                "application/json": {
                  schema: {
                    $ref: "#/components/schemas/JwtResponse",
                  },
                },
              },
            },
            "401": {
              description: "Credenciais inválidas",
            },
          },
        },
      },
    },
    components: {
      schemas: {
        Supplier: {
          type: "object",
          properties: {
            id: {
              type: "integer",
              format: "int64",
              readOnly: true,
            },
            name: {
              type: "string",
            },
            taxId: {
              type: "string",
            },
            email: {
              type: "string",
              format: "email",
            },
            phone: {
              type: "string",
            },
            address: {
              type: "string",
            },
            city: {
              type: "string",
            },
            state: {
              type: "string",
            },
            country: {
              type: "string",
            },
            postalCode: {
              type: "string",
            },
            website: {
              type: "string",
            },
            status: {
              type: "string",
              enum: ["ACTIVE", "INACTIVE", "PENDING", "SUSPENDED"],
            },
            createdAt: {
              type: "string",
              format: "date-time",
              readOnly: true,
            },
            updatedAt: {
              type: "string",
              format: "date-time",
              readOnly: true,
            },
          },
        },
        PageSupplier: {
          type: "object",
          properties: {
            content: {
              type: "array",
              items: {
                $ref: "#/components/schemas/Supplier",
              },
            },
            pageable: {
              type: "object",
            },
            totalElements: {
              type: "integer",
              format: "int64",
            },
            totalPages: {
              type: "integer",
            },
            last: {
              type: "boolean",
            },
            size: {
              type: "integer",
            },
            number: {
              type: "integer",
            },
            sort: {
              type: "object",
            },
            numberOfElements: {
              type: "integer",
            },
            first: {
              type: "boolean",
            },
            empty: {
              type: "boolean",
            },
          },
        },
        LoginRequest: {
          type: "object",
          properties: {
            username: {
              type: "string",
            },
            password: {
              type: "string",
              format: "password",
            },
          },
          required: ["username", "password"],
        },
        JwtResponse: {
          type: "object",
          properties: {
            token: {
              type: "string",
            },
            type: {
              type: "string",
              example: "Bearer",
            },
            id: {
              type: "integer",
              format: "int64",
            },
            username: {
              type: "string",
            },
            roles: {
              type: "array",
              items: {
                type: "string",
              },
            },
          },
        },
      },
      securitySchemes: {
        bearerAuth: {
          type: "http",
          scheme: "bearer",
          bearerFormat: "JWT",
          description: "Forneça o token JWT no formato: Bearer {token}",
        },
      },
    },
  }

  return (
    <div className="container mx-auto py-6">
      <h1 className="text-3xl font-bold mb-6">Documentação da API Najason</h1>
      <div className="bg-white p-4 rounded-lg shadow">
        <SwaggerUI spec={spec} />
      </div>
    </div>
  )
}
